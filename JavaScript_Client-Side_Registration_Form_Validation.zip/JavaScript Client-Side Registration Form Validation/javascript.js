const form = document.getElementById("form") 
const username = document.getElementById("username")
const email = document.getElementById("email")
const password = document.getElementById("password")
const password2 = document.getElementById("password2")


form.addEventListener('submit', (e) =>{
    e.preventDefault()

    checkInput()
})

function checkInput(){
    const usernameValue = username.value.trim()
    const emailValue = email.value.trim()
    const passwordValue = password.value.trim()
    const password2Value = password2.value.trim()

    if(usernameValue === ''){
        //display error message
        //add error class
        setError(username,'Username can not be blank')
    } else{
        setForSuccess(username)
    }

    if( emailValue === ''){
        setError(email,'Email can not be blank')
    }else{
        setForSuccess(email)
    }

    if(passwordValue === ''){
        setError(password,'Password can not be blank')
    }else{
        setForSuccess(password)
    }

    if(password2Value === ''){
        setError(password2,'Password can not be blank')
    }else if (passwordValue !== password2Value){
        setError(password,'Password doesn\'t match')
    }else{
        setForSuccess(password2)
    }
}

function setError(input, message){
    const formControl = input.parentElement //.form-control class
    
    const small = formControl.querySelector('small')

    //add error msg inside small
    small.innerText = message
    //add error class
    formControl.className = 'form-control error'
}

function setForSuccess(input){
    const formControl = input.parentElement
    formControl.className = 'form-control success'
}