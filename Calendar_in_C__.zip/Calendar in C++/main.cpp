#include <iostream>
#include <iomanip>
using namespace std;

//Variables needed to print calendar of given year and month

void printMonth(int month, int year); // print the entered month
void printMonthTitle(int year, int month);
void printMonthName(int month); // name of month in the header
void printMonthBody(int month, int year); //where there will be original calendar
int getStartOfDay(int month, int year); // the first day of the month
int getTotalNumberOfDays(int month, int year);  // in whole year
int getNumberOfDaysInMonth(int month, int year); //how many days in month
bool isLeap(int year);//whether year is leap

int main(){

	int month, year;
	cout<<"Enter full year(example 2021): ";
	cin>>year;

	cout <<"Enter month in number between 1 and 12: ";
	cin>>month;

	printMonth(month, year);
	return 0;
}


void printMonth(int month, int year){
	//printing headings of calendar
    printMonthName(month);
 	cout << "    " <<year<<"	"<<endl;
 	cout <<"---------------------------"<<endl;
 	cout <<"SUN"<<setw(5)<<"MON"<<setw(5)<<"TUE"<<setw(5)<<"WEN"<<setw(5)<<"THU"<<setw(5)<<"FRI"<<setw(5)<<"SAT"<<endl;

	//printing the body of month
	printMonthBody(month, year);
}

void printMonthName(int month){
	switch(month){
		case 1:
			cout <<"January";
			break;
		case 2:
			cout <<"February";
			break;
		case 3:
			cout <<"March";
			break;
		case 4:
			cout <<"April";
			break;
		case 5:
			cout <<"May";
			break;
		case 6:
			cout <<"June";
			break;
		case 7:
			cout <<"July";
			break;
		case 8:
			cout <<"August";
			break;
		case 9:
			cout <<"September";
			break;
		case 10:
			cout <<"Octber";
			break;
		case 11:
			cout <<"November";
			break;
		case 12:
			cout <<"December";
			break;
		default:
			cout<<"Null" <<endl;
			break;

	}
}
void printMonthBody(int month, int year){
	//get the start day in month
	int startDay= getStartOfDay(month, year);
	//get the number of days in month
	int numberOfDaysInMonth= getNumberOfDaysInMonth(month, year);

	//pad space between dates
	int i;
	for (i=0; i< startDay; i++){
	cout << " ";
	}
	for(i=1; i<=numberOfDaysInMonth; i++) {
		cout <<setw(5) <<i;

		if( (i + startDay) % 7 ==0 ) {
			cout <<endl;
		}
	}
}

int getStartOfDay(int month, int year){
	// to get the total number of days from 1800
	int startDay1800= 3;
	int totalNumberOfDays=getTotalNumberOfDays(month, year);
	//return the start day
	return(totalNumberOfDays + startDay1800) % 7;
}

int getTotalNumberOfDays(int month, int year){
	int total =0;
	for(int i=1800; i<year; i++){
		if(isLeap(i)){
			total += 366;
		} else{
			total += 365;
		}
	}

	//Add days from Jan to month prior the present month
	for (int i=1; i<month; i++) {

		total += getNumberOfDaysInMonth(i, year);
	}

	return total;
}

int getNumberOfDaysInMonth(int month, int year){
	if(month ==1 || month == 3 || month ==5 || month == 7
	   || month == 8|| month == 10 || month == 12) {

	   	return 31;
	}
	if (month == 4 || month == 6 || month == 9
		|| month == 11) {

			return 30;
		}

	if(month == 2 && isLeap(year)) {

		return 28;
	}
	if((month == 2) && !(isLeap(year))) {
		return 29;
	}

	return 0;
}

bool isLeap(int year){
	if(year % 400 ==0 || year % 4 ==0 && year%100 !=0){
		return true;
	} else{
		return false;
	}
}
