const months = [
    "January",
    "February",
    "March", 
    "April", 
    "May", 
    "June", 
    "July", 
    "August", 
    "September", 
    "OCtober", 
    "November", 
    "December"
]
  const weekDays=[
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
]

//getting future date
const futureDate = new Date(2023, 2, 01, 00, 00, 0)
const year = futureDate.getFullYear()
const hours = futureDate.getHours()
const minutes = futureDate.getMinutes()
const seconds = futureDate.getSeconds()
const month = months[futureDate.getMonth()]
const day = weekDays[futureDate.getDay()-1]
const date = futureDate.getDate()
let giveaway = document.querySelector(".giveaway")
let timeLimitContainer = document.querySelectorAll(".time-limit h1")
let deadline = document.querySelector(".deadline")
giveaway.innerHTML = `
<h4 class = "giveaway"> Promotion ends 
${day}, ${date} ${month} ${year} at ${hours}:${minutes}:${seconds} pm
`

//getting future time

const futureTime =  futureDate.getTime()
function getRemainingTime(){
    const today = new Date().getTime()
    let difference = futureTime - today;

    // 1s = 1000ms
    // 1min = 60s
    // 1h = 60 min
    // 1d = 24hr

    const oneDay = 24 * 3600 *1000;
    const oneHour = 3600 * 1000;
    const oneMin = 60 * 1000;
    const oneSec = 1000
    
    let numberOfDays =Math.floor(difference/oneDay)
    let numberOfHours = Math.floor((difference % oneDay) / oneHour)
    let numberOfMinutes = Math.floor((difference% oneHour) / oneMin)
    let numberOfSec = Math.floor((difference % oneMin)/1000)

    let output = [
        numberOfDays,
        numberOfHours,
        numberOfMinutes,
        numberOfSec
    ]

    function format(item){
        if(item < 10){
            return `0${item}`
        }
        return item
    }
    timeLimitContainer.forEach(function(item, index){
        return item.innerHTML = format(output[index])
    })

    if(difference <0){
        clearInterval(timeOut)
        deadline.innerHTML = `<h4 style="color: red; text-align: center; font-family: trebuchet MS"> This giveaway has expired</h4>`
    }
}

const timeOut = setInterval( getRemainingTime, 1000)

getRemainingTime()