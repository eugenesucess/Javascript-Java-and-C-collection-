let scoreContainer = document.getElementById("score")
function renderScore(){
    scoreContainer.style.display="block"
    const scorePercent = Math.round( score * 100/ questions.length);
    let img = (scorePercent >=80) ? "img/5.png":
         (scorePercent >=60)? "img/4.png":
         (scorePercent >=40)? "img/3.png":
         (scorePercent >=20)? "img/2.png":
         "img/1.png";
    scoreContainer.innerHTML = "<img src ="+img+">"
    scoreContainer.innerHTML += "<p> Your score is: " +scorePercent+"%</p>"
}