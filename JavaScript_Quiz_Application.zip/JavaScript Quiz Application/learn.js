const start = document.getElementById("start");
const quiz = document.getElementById("quiz");
const question = document.getElementById("question");
const qImg = document.getElementById("qImg");
const choices = document.getElementById("choices");
const choiceA = document.getElementById("A");
const choiceB = document.getElementById("B");
const choiceC = document.getElementById("C");
const counter = document.getElementById("counter");
const timeGauge = document.getElementById("timeGauge");
const btimeGauge = document.getElementById("btimeGauge");
const progress = document.getElementById("progress");
const tryAgin = document.querySelector('.try')

//create questions

let questions = [
    {
        question:"What does HTML stand for?",
        imgSrc: "img/html.png",
        choiceA: "Hyper Text Markup Language",
        choiceB: "Higher Text Markup Language",
        choiceC: "Hyper Text Making Language",
        correct: "A"
    },{
        question:"What does CSS stand for?",
        imgSrc: "css.jpg",
        choiceA: "Can Style Screen",
        choiceB: "Cascading Stylesheet Style",
        choiceC: "Cascading Style Stylesheet",
        correct: "B"
    },{
        question:"What does JS stand for?",
        imgSrc: "js.jpg",
        choiceA: "JavaServer",
        choiceB: "JavaSand",
        choiceC: "javaScript",
        correct: "C"
    }
];

//create some variables

const lastQuestion = questions.length -1;
let runningQuestion=0;
let count = 0;
const questionTime = 10;
const guageWidth = 150; //150px
const gaugeUnit = guageWidth / questionTime;
let timer;
let score = 0;

//render a question

function renderQuestion(){
    let currentQuestion = questions[runningQuestion]
    question.innerHTML = "<p>" + currentQuestion.question +"</p"
    qImg.innerHTML = "<img src="+ currentQuestion.imgSrc +">"
    choiceA.innerHTML = currentQuestion.choiceA
    choiceB.innerHTML = currentQuestion.choiceB
    choiceC.innerHTML = currentQuestion.choiceC
}
timeGauge.style.display="none"
btimeGauge.style.display="none"
choices.style.display="none"

start.addEventListener('click', startQuiz)

//start quiz function
function startQuiz()
{   
    timeGauge.style.display=""
    btimeGauge.style.display=""
    choices.style.display=""
    start.style.display="none"
    renderQuestion()
    quiz.style.display="block"
    // render progress
    renderProgress()
    //render counter
    renderCounter()
    timer = setInterval(renderCounter, 1000) //1000ms = 1s
}

//click start and start quiz

let scoreContainer = document.getElementById("score")
function renderScore(){
    scoreContainer.style.display="block"
    const scorePercent = Math.round( score * 100/ questions.length);
    let img = (scorePercent >=80) ? "img/5.png":
         (scorePercent >=60)? "img/4.png":
         (scorePercent >=40)? "img/3.png":
         (scorePercent >=20)? "img/2.png":
         "img/1.png";
    scoreContainer.innerHTML = "<img src ="+img+">"
    scoreContainer.innerHTML += "<p> Your score is: " +scorePercent+"%</p>"  
} 

//render progress
function renderProgress(){
    for(let qIndex = 0; qIndex <=lastQuestion; qIndex++){
        progress.innerHTML += "<div class= 'prog' id= " + qIndex +"></div>"
    }
}

//render counter
function renderCounter(){
    if(count <=questionTime){ // if we still have time to answer
        counter.innerHTML = count; 
        timeGauge.style.width = count * 15 + "px";
        count++;
    } else{ //here means time is up!
        
        answerIsWrong()
        count = 0;
         //we need to go the next question if right or wrong
        if(runningQuestion < lastQuestion){
            runningQuestion++;
            renderQuestion()
        }else{
            clearInterval(timer)
            tryAgin.classList.add('active');
            tryAgin.style.display="block"
            renderScore()
        }
    }
}

    tryAgin.addEventListener('click', ()=>{
        start.style.display='block'
        quiz.style.display="none"
        count=0
        runningQuestion=0;
        score=0;
        scoreContainer.style.display="none"
        progress.innerHTML=""
        tryAgin.style.display="none"
    })
//check if answer is true

function checkAnswer(answer){
    if(answer == questions[runningQuestion].correct){
        //answer is correct
        score++;
        //change progress color to green
        answerIsCorrect()
    } else{
        //answer is wrong
        //change progress color to red
        answerIsWrong()
    }
    
    count = 0;

     //we need to go the next question if right or wrong
    if(runningQuestion < lastQuestion){ //if there is next question
        runningQuestion++;
        renderQuestion()
    } else{ //if there is no next question
        //end quiz and show scores
        clearInterval(timer)
        renderScore()
        tryAgin.classList.add('active');
        tryAgin.style.display='block'
    }
}

function answerIsCorrect(){
    document.getElementById(runningQuestion).style.backgroundColor="green";
}

function answerIsWrong(){
    document.getElementById(runningQuestion).style.backgroundColor="red";
}



