#include <iostream>
using namespace std;

class Cube
{
public:
    double length;
    double breadth;
    double height;


    //declaration of members of class

    double getVolume(void);
    void setLength(double l);
    void setBreadth(double b);
    void setHeight(double h);
};

//Member of class definition

double Cube::getVolume(void)
{
    return length*breadth*height;
}
void Cube::setLength(double l)
{
    length=l;
}
void Cube::setBreadth(double b)
{
    breadth=b;
}
void Cube::setHeight(double h)
{
    height=h;
}

int main()
{
    Cube C1;
    Cube C2;
    double volume;

    C1.setLength(3.0);
    C1.setBreadth(10.0);
    C1.setHeight(5.0);

    C2.setLength(20.0);
    C2.setBreadth(4.0);
    C2.setHeight(8.0);

    volume=C1.getVolume();
    cout <<"Volume of first Cube is: " <<volume<<endl;

    volume=C2.getVolume();
    cout<<"Volume of second Cube is: " <<volume<<endl;

    return 0;
}
